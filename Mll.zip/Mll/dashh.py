#!/usr/bin/env python
# coding: utf-8

# In[25]:


import streamlit as st


# In[27]:


import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Title and Description
st.title("EDA Dashboard for Heart Disease Dataset")
st.write("This app allows you to explore and visualize the `imputed_data.csv` dataset interactively.")

# Upload File
uploaded_file = st.file_uploader("Upload your CSV file (imputed_data.csv)", type=["csv"])

# Proceed if file is uploaded
if uploaded_file:
    df = pd.read_csv(uploaded_file)
    st.write("### Dataset Overview")
    st.write(df.head())

    # Show Basic Info
    if st.checkbox("Show Dataset Info"):
        buffer = []
        df.info(buf=buffer)
        info_str = "\n".join(buffer)
        st.text(info_str)

    # Summary Statistics
    if st.checkbox("Show Statistical Summary"):
        st.write(df.describe(include='all'))  # Include all columns for summary

    # Missing Values
    if st.checkbox("Show Missing Values"):
        st.write(df.isnull().sum())

    # Visualizations
    st.write("## Visualizations")

    # Correlation Heatmap
    if st.checkbox("Show Correlation Heatmap (Numeric Data)"):
        st.write("### Correlation Heatmap")
        numeric_cols = df.select_dtypes(include=['float64', 'int64']).columns
        plt.figure(figsize=(10, 6))
        sns.heatmap(df[numeric_cols].corr(), annot=True, cmap='coolwarm')
        st.pyplot(plt)

    # Countplot for Categorical Columns
    if st.checkbox("Show Countplot for a Categorical Column"):
        st.write("### Countplot")
        cat_column = st.selectbox("Select a Categorical Column", df.select_dtypes(include=['object']).columns)
        plt.figure(figsize=(10, 6))
        sns.countplot(x=df[cat_column])
        plt.xticks(rotation=45)
        st.pyplot(plt)

    # Boxplot
    if st.checkbox("Show Boxplot"):
        st.write("### Boxplot")
        num_col = st.selectbox("Select a Numeric Column for Boxplot", df.select_dtypes(include=['float64', 'int64']).columns)
        cat_col = st.selectbox("Select a Categorical Column for Grouping", df.select_dtypes(include=['object']).columns)
        plt.figure(figsize=(10, 6))
        sns.boxplot(x=df[cat_col], y=df[num_col])
        plt.xticks(rotation=45)
        st.pyplot(plt)

    # Scatter Plot
    if st.checkbox("Show Scatter Plot"):
        st.write("### Scatter Plot")
        num_cols = df.select_dtypes(include=['float64', 'int64']).columns
        x_col = st.selectbox("Select X-axis Column", num_cols)
        y_col = st.selectbox("Select Y-axis Column", num_cols)
        plt.figure(figsize=(10, 6))
        sns.scatterplot(x=df[x_col], y=df[y_col])
        st.pyplot(plt)

    # Histogram for Numeric Data
    if st.checkbox("Show Histogram for Numeric Column"):
        st.write("### Histogram")
        selected_col = st.selectbox("Select a Numeric Column", df.select_dtypes(include=['float64', 'int64']).columns)
        plt.figure(figsize=(10, 6))
        sns.histplot(df[selected_col], kde=True, bins=20)
        st.pyplot(plt)

    # Distribution Plot for Numeric Columns
    if st.checkbox("Show Distribution Plot for a Numeric Column"):
        st.write("### Distribution Plot")
        selected_col = st.selectbox("Select a Column", df.select_dtypes(include=['float64', 'int64']).columns)
        plt.figure(figsize=(10, 6))
        sns.kdeplot(df[selected_col], shade=True)
        st.pyplot(plt)

else:
    st.write("Upload a file to start exploring.")


# In[ ]:





# In[ ]:





# In[ ]:




